import './bootstrap';
import './theme-manager';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
