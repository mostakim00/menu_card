<!-- plugins:js -->
<script src="<?php echo e(asset('backend/vendors/js/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="<?php echo e(asset('backend/vendors/chart.js/chart.umd.js')); ?>"></script>

<script src="<?php echo e(asset('backend/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="<?php echo e(asset('backend/js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/settings.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/todolist.js')); ?>"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?php echo e(asset('backend/js/jquery.cookie.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('backend/js/dashboard.js')); ?>"></script>
<!-- <script src="js/Chart.roundedBarCharts.js"></script> -->
<!-- End custom js for this page-->

<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- toastr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>





<script>
    $(document).ready(function() {
        toastr.options.timeOut = 10000;
        toastr.options.positionClass = 'toast-top-right';

        <?php if(Session::has('t-success')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.success("<?php echo e(session('t-success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-error')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.error("<?php echo e(session('t-error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-info')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.info("<?php echo e(session('t-info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('t-warning')): ?>
            toastr.options = {
                'closeButton': true,
                'debug': false,
                'newestOnTop': true,
                'progressBar': true,
                'positionClass': 'toast-top-right',
                'preventDuplicates': false,
                'showDuration': '1000',
                'hideDuration': '1000',
                'timeOut': '5000',
                'extendedTimeOut': '1000',
                'showEasing': 'swing',
                'hideEasing': 'linear',
                'showMethod': 'fadeIn',
                'hideMethod': 'fadeOut',
            };
            toastr.warning("<?php echo e(session('t-warning')); ?>");
        <?php endif; ?>
    });
</script>

<!-- CSRF -->
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<?php echo $__env->yieldPushContent('script'); ?>
<?php /**PATH E:\Freelance_froject\1\wsim-backend-main\resources\views/partials/script.blade.php ENDPATH**/ ?>