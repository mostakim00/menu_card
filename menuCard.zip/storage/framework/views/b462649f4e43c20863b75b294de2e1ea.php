<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">

    </div>
</footer>
<?php /**PATH E:\Freelance_froject\1\wsim-backend-main\resources\views/partials/footer.blade.php ENDPATH**/ ?>